import React from "react"

export default function Navbar(){
    return(
        <div> 
            <h2 className = "navbar"> my travel journal</h2> 
        </div> 
    )
}